#include "SimpleRange.h"
#include "SmartRange.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <memory>

using namespace std;

int main()
{
    assert((gcd<12,15>::value == 3));
    assert((gcd<15,12>::value == 3));
    assert((gcd<15,13>::value == 1));
    assert((gcd<15,5>::value  == 5));

    const uint32_t v_reduce = (1u << 30) + 12u;
    assert((random_traits<uint32_t, v_reduce>::last == 3221225507u));
    assert((random_traits<uint32_t, v_reduce>::gcd  == 4));
    assert((random_traits<uint32_t, v_reduce>::dispatch == random_dispatch::REDUCE_MAX));

    const int32_t v_direct = (1 << 20);
    assert((random_traits<int32_t, v_direct>::last == 2147483647));
    assert((random_traits<int32_t, v_direct>::gcd  == v_direct));
    assert((random_traits<int32_t, v_direct>::dispatch == random_dispatch::NO_LOOP));

    const uint32_t v_retry = (1u << 31) + 1u;
    assert((random_traits<uint32_t, v_retry>::last == 2147483648u));
    assert((random_traits<uint32_t, v_retry>::gcd  == 1));
    assert((random_traits<uint32_t, v_retry>::dispatch == random_dispatch::RETRY_SAME));


    SimpleRange simple(1234);
    SmartRange  smart(1234);

    const unsigned max1   = (1u << 31) + (1u << 30);
    const unsigned max2   = 10;

    for (int i = 0;  i < 100;  ++i) {
        unsigned v1 = smart.next<max1>();
        unsigned v2 = smart.next<max2>();

        assert(v1 < max1);
        assert(v2 < max2);
    }

    const int count = 1000000;
    int count1 = 0;
    int count2 = 0;

    for (int i = 0;  i < count;  ++i) {
        unsigned v1 = smart.next<max1>();
        unsigned v2 = simple.next(max1);

        count1 += v1 < max1 / 2;
        count2 += v2 < max1 / 2;
    }

    assert(abs(count - count1 * 2) < count / 1000);
    assert(abs(count - count2 * 2) < count / 1000);

    simple.next();
    smart.next();

    
    auto_ptr<Random> rand(new SimpleRange(123));
    rand.reset(new SmartRange(456));
}
