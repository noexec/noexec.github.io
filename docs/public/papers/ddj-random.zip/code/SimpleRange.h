#ifndef SimpleRange_H
#define SimpleRange_H

#include "Random.h"

/*
 * Uniform distribution on [0,max).
 */

class SimpleRange : public Random
{
public:
    using Random::next;

    SimpleRange(value_t seed) : Random(seed) { }
    value_t next(value_t max);
};

#endif
