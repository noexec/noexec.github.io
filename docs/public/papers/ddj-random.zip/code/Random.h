#ifndef Random_H
#define Random_H

#include "mtrand.h"

/*
 * A wrapper interface for a random number generator
 * implementation.
 */

class Random
{
public:
    typedef unsigned value_t;

    Random(value_t seed) : mtrand(seed), _stats() { }
    virtual ~Random() { }

    value_t next() { ++_stats; return mtrand(); }

    // Statistics are for demonstration purposes
    value_t stats() const { return _stats; }

private:
    // Mersenne Twister 19937 generator, see http://bedaux.net/mtrand/
    MTRand_int32 mtrand;
    value_t      _stats;
};

#endif
