#ifndef gcd_H
#define gcd_H

// <cstdint> should be available with TR1
#include <stdint.h>

/*
 * Compute greatest common divisor in compile-time.
 *
 * boost::math::static_gcd can be used instead.
 */

template <uintmax_t a, uintmax_t b> struct gcd
{ static const uintmax_t value = gcd<b, a%b>::value; };

template <uintmax_t a> struct gcd<a, 0>
{ static const uintmax_t value = a; };

#endif
