#ifndef SmartRange_H
#define SmartRange_H

#include "Random.h"
#include "random_traits.h"

namespace detail
{
namespace SmartRange
{

    /*
     * The Dispatch class is an implementation detail --
     * we wouldn't need it if C++ allowed partial specialization
     * for member functions.
     */

    template <Random::value_t max,
              random_dispatch::dispatch_t = random_traits<Random::value_t, max>::dispatch>
    class Dispatch;


    // Specialization: all values are accepted
    template <Random::value_t max>
    class Dispatch<max, random_dispatch::NO_LOOP>
    {
        typedef Random::value_t value_t;

    public:
        static value_t next(Random& random)
        {
            // rnd <- [0 .. M]
            const value_t rnd = random.next();
            return rnd % max;
        }
    };


    // Specialization: rejection of remainder values
    template <Random::value_t max>
    class Dispatch<max, random_dispatch::RETRY_SAME>
    {
        typedef Random::value_t             value_t;
        typedef random_traits<value_t, max> random_traits;

    public:
        static value_t next(Random& random)
        {
            value_t rnd;

            // Once rnd is in the safe range of
            // [0 .. last], return rnd % max
            do
                // rnd <- [0 .. M]
                rnd = random.next();
            while (rnd > random_traits::last);

            return rnd % max;
        }
    };


    // Specialization: reduction of max
    template <Random::value_t max>
    class Dispatch<max, random_dispatch::REDUCE_MAX>
    {
        typedef Random::value_t             value_t;
        typedef random_traits<value_t, max> random_traits;

    public:
        static value_t next(Random& random)
        {
            // rnd <- [0 .. M]
            const value_t rnd = random.next();

            // If rnd is in the safe range of
            // [0 .. last], return rnd % max
            if (rnd <= random_traits::last)
                return rnd % max;

            // Otherwise, we have the partial random value
            // in [last+1 .. M] range, and use it if possible
            // (this can happen only once, but it doesn't
            // matter for the implementation).
            else
                return max/random_traits::gcd *
                           ((rnd - (random_traits::last + 1)) % random_traits::gcd)
                       + Dispatch<max/random_traits::gcd>::next(random);
        }
    };

}
}


/*
 * Uniform distribution on [0,max) for compile-time constant max.
 */

class SmartRange : public Random
{
public:
    using Random::next;

    SmartRange(value_t seed) : Random(seed) { }

    template <value_t max> value_t next()
    { return detail::SmartRange::Dispatch<max>::next(*this); }
};

#endif
