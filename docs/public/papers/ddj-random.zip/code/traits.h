#ifndef traits_H
#define traits_H

#include <climits>

/*
 * Overcome the difficulty of std::numeric_limits<...>::max()
 * not being accessible at compile-time.
 *
 * boost::integer_traits can be used instead.
 */

template <typename> struct traits;

template <> struct traits<unsigned>
{ static const unsigned max_value = UINT_MAX; };

template <> struct traits<int>
{ static const int max_value = INT_MAX; };

#endif
