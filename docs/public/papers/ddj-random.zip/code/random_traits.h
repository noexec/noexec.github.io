#ifndef random_traits_H
#define random_traits_H

#include "traits.h"
#include "gcd.h"

/*
 * Dispatch types for next<max>() functions.
 */

namespace random_dispatch
{
    enum dispatch_t
    {
        NO_LOOP,       // rem == 0
        RETRY_SAME,    // gcd == 1
        REDUCE_MAX     // gcd != 1
    };
}


/*
 * Dispatch type and auxiliary data for combining
 * dispatch results.
 */

template <typename value_t, value_t max>
struct random_traits
{
private:
    static const value_t M    = traits<value_t>::max_value;
    static const value_t rem  = (M - (max - 1)) % max;

public:
    static const value_t last = M - rem;
    static const value_t gcd  = gcd<max,rem>::value;

    static const random_dispatch::dispatch_t dispatch =
        rem == 0  ? random_dispatch::NO_LOOP
        : (gcd == 1 ? random_dispatch::RETRY_SAME
           : random_dispatch::REDUCE_MAX);
};

#endif
