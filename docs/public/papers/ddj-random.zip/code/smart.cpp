#include "SmartRange.h"
#include <iostream>

using namespace std;

int main()
{
    SmartRange rand(1234);

    const unsigned max   = (1u << 31) + 32;
    const int      count = 10000000;

    for (int i = 0;  i < count;  ++i)
        rand.next<max>();

    cout << "Average next() calls per next(max): "
         << rand.stats() / (count + 0.0)
         << endl;
}

