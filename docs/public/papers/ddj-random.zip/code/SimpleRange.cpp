#include "SimpleRange.h"
#include <limits>

Random::value_t SimpleRange::next(value_t max)
{
    const value_t M    = std::numeric_limits<value_t>::max();
    const value_t rem  = (M - (max - 1)) % max;
    const value_t last = M - rem;

    value_t rnd;

    // Once rnd is in the safe range of
    // [0 .. last], return rnd % max
    do
        // rnd <- [0 .. M]
        rnd = next();
    while (rnd > last);

    return rnd % max; 
}
